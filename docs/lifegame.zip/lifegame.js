﻿// 第7回 例題2
// 以下を変更したり、必要な処理を追加したりしてライフゲームを実装せよ

// 開始ボタンが押されると呼ばれる
function startLifegame() {
  // これはコンソールにログを出す命令。デバッグに使う
  console.log("startLifegame");
}

// 停止ボタンが押されると呼ばれる
function stopLifegame() {
  console.log("stopLifegame");
}

// htmlの読み込みが完了するとこの処理が行われる
window.onload = function () {
  let world = [];
  let timer = 0;
  let canvas;
  let context;

  // htmlに幅500px, 高さ500px, idが"lifegameCanvas"である
  // canvas要素が用意されており、それを取得している。
  canvas = document.getElementById('lifegameCanvas');
  context = lifegameCanvas.getContext('2d');

  // 以下描画のサンプル処理

  // 領域を一度消す
  context.clearRect(0,0,500,500);

  // 青色の設定をする
  context.fillStyle = "rgb(0, 0, 255)";

  // 座標(100,0)に幅200px, 高さ300pxの四角形を書く
  context.fillRect(100,0, 200, 300);
}
